import java.io.*;
import java.util.Scanner;

public class FileEncryptionDecryption {
    private static final int SHIFT_KEY = 3;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the file path: ");
        String filePath = scanner.nextLine();
        
        System.out.print("Choose operation (encrypt/decrypt): ");
        String operation = scanner.nextLine().toLowerCase();
        
        String outputFilePath = filePath + (operation.equals("encrypt") ? ".enc" : ".dec");
        
        try {
            processFile(filePath, outputFilePath, operation.equals("encrypt"));
            System.out.println("Operation completed. Output file: " + outputFilePath);
        } catch (IOException e) {
            System.out.println("Error processing file: " + e.getMessage());
        }
        
        scanner.close();
    }

    private static void processFile(String inputFilePath, String outputFilePath, boolean encrypt) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFilePath));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
            
            int shift = encrypt ? SHIFT_KEY : -SHIFT_KEY;
            int c;
            while ((c = reader.read()) != -1) {
                writer.write(c + shift);
            }
        }
    }
}
