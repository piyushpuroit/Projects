import java.util.*;
public class TemperatureConverter{
public static void main(String[]args){
    Scanner sc = new Scanner(System.in);

   // To Enter temperature value 
    System.out.print("Enter temperature value:");
    Double temp = sc.nextDouble();

    // Asking for the unit
    System.out.print("Enter its unit (C for Celsius, F for Fahrenheit):");
    char unit = sc.next().toUpperCase().charAt(0);

    // Conversion Celsius to Fahrenheit
    if(unit == 'C'){
        double FH = (temp*9 / 5) + 32;
        System.out.println("Conversion to Fahrenheit: "+ FH + "°F");
    }

    // Conversion Fahrenheit to Celsius
    else if(unit == 'F'){
        double C = (temp - 32) * 5 / 9;
        System.out.println("Conversion to Celsius: "+ C + "°C");
    }
    
    else{
        System.out.println("Invalid unit entered. Please enter C or F.");
    }
    sc.close();
  }
}