import java.util.Random;
import java.util.Scanner;

public class RandomPasswordGenerator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random random = new Random();

        // Get password length
        System.out.print("Enter the desired password length: ");
        int length = sc.nextInt();

        // Asking user for character types
        System.out.print("Include numbers? (yes/no): ");
        boolean includeNumbers = sc.next().equalsIgnoreCase("yes");

        System.out.print("Include lowercase letters? (yes/no): ");
        boolean includeLower = sc.next().equalsIgnoreCase("yes");

        System.out.print("Include uppercase letters? (yes/no): ");
        boolean includeUpper = sc.next().equalsIgnoreCase("yes");

        System.out.print("Include special characters? (yes/no): ");
        boolean includeSpecial = sc.next().equalsIgnoreCase("yes");

        // Define character pools
        String numbers = "0123456789";
        String lowercase = "abcdefghijklmnopqrstuvwxyz";
        String uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String specialChars = "!@#$%^&*()-_=+<>?";

        // Build the character pool based on user choices
        String charPool = "";
        if (includeNumbers) charPool += numbers;
        if (includeLower) charPool += lowercase;
        if (includeUpper) charPool += uppercase;
        if (includeSpecial) charPool += specialChars;

        // Ensure at least one character type is selected
        if (charPool.isEmpty()) {
            System.out.println("You must select at least one character type!");
            return;
        }

        // Generate password
        StringBuilder password = new StringBuilder();
        for (int i = 0; i < length; i++) {
            int index = random.nextInt(charPool.length());
            password.append(charPool.charAt(index));
        }

        // Display generated password
        System.out.println("Generated Password: " + password.toString());

        sc.close();
    }
}

