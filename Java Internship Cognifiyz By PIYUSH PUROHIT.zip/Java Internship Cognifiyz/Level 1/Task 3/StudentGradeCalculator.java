import java.util.Scanner;
public class StudentGradeCalculator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Ask to enter the number of grades
        System.out.print("Enter the number of grades: ");
        int numGrades = sc.nextInt();

        // Array to store grades
        double[] grades = new double[numGrades];
        double sum = 0;

        // iterating to take grades input
        for (int i = 0; i < numGrades; i++) {
            System.out.print("Enter grade " + (i + 1) + ": ");
            grades[i] = sc.nextDouble();
            sum += grades[i]; // Add to sum
        }

        // Calculate average
        double average = sum / numGrades;

        // Display average grade
        System.out.println("Average Grade: " + average);

        sc.close();
    }
}
