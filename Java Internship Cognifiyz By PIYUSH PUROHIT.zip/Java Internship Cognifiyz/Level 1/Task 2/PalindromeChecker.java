import java.util.Scanner;
public class PalindromeChecker {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // taking input from User
        System.out.print("Enter a Word or Phrase: ");
        String input = sc.nextLine();

        //Clean the input (removing spaces & punctuation, converting to lowercase)
        String cleanInput = input.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();

        // Reverse the cleanInput String as String Builder
        String reversInput = new StringBuilder(cleanInput).reverse().toString();

        // Check if palindrome(comparing cleaninput to reverseInput)
        if (cleanInput.equals(reversInput)) {
            System.out.println("The given input is a palindrome.");
        } else {
            System.out.println("The given input is NOT a palindrome.");
        }

        sc.close();
    }
}
